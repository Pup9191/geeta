let selectedSticker="💖";

/* Flip */
document.querySelectorAll('.img').forEach(img=>{
    img.onclick=()=>img.parentElement.classList.toggle('flip');
});

/* Stickers */
document.querySelectorAll('.st').forEach(s=>{
    s.onclick=()=>selectedSticker=s.textContent;
});

/* Add sticker */
document.querySelectorAll('.addSticker').forEach(btn=>{
    btn.onclick=()=>{
        let o=btn.parentElement.querySelector('.overlay');
        let e=document.createElement('span');
        e.textContent=selectedSticker;
        e.style.position="absolute";
        e.style.left=Math.random()*120+"px";
        e.style.top=Math.random()*200+"px";
        e.style.fontSize="32px";
        o.appendChild(e);
    };
});

/* Captions */
const captions=[
"Geeta = cutest human alive 💖",
"Warning: Geeta too cute 😳",
"This smile deserves an award ✨",
"No sadness allowed for Geeta 💗",
"CEO of being adorable 💞",
"Geeta = sunshine factory 🌸"
];

document.getElementById('randomCaption').onclick=()=>{
    document.querySelectorAll('.caption').forEach(c=>{
        c.textContent=captions[Math.floor(Math.random()*captions.length)];
    });
};

/* ✅ Music FIX */
let bg=document.getElementById('bgm');

// allow sound after first user click
document.body.addEventListener("click", function enable(){
    bg.play().catch(()=>{});
    document.body.removeEventListener("click", enable);
});

document.getElementById('musicBtn').onclick=()=>{
    if(bg.paused){
        bg.play();
        document.getElementById('musicBtn').innerText="⏸ Pause";
    } else {
        bg.pause();
        document.getElementById('musicBtn').innerText="🎵 Music";
    }
};

/* Voice */
const msgs=[
"Geeta please smile, your happiness matters!",
"Geeta is the cutest person ever!",
"Hey Geeta! You're amazing!",
"Smile Geeta, you look beautiful!"
];

document.getElementById('voiceBtn').onclick=()=>{
    let m=new SpeechSynthesisUtterance(
        msgs[Math.floor(Math.random()*msgs.length)]
    );
    speechSynthesis.speak(m);
};

/* Confetti */
document.getElementById('cheerBtn').onclick=()=>{
startConfetti();
let m=new SpeechSynthesisUtterance("Cheer up Geeta! You are loved!");
speechSynthesis.speak(m);
};

function startConfetti(){
const c=document.getElementById('confetti');
const x=c.getContext('2d');
c.width=innerWidth;c.height=innerHeight;
let p=[];
for(let i=0;i<120;i++){
p.push({
x:Math.random()*innerWidth,
y:Math.random()*innerHeight,
vy:Math.random()*3+1,
size:Math.random()*6+3,
color:`hsl(${Math.random()*360},100%,70%)`
});
}
function draw(){
x.clearRect(0,0,c.width,c.height);
p.forEach(a=>{
a.y+=a.vy;
if(a.y>c.height)a.y=-10;
x.fillStyle=a.color;
x.fillRect(a.x,a.y,a.size,a.size);
});
requestAnimationFrame(draw);
}
draw();
}
